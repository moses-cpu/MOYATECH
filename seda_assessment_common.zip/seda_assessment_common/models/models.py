# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Options(models.Model):
    _name = "seda.assessment.question.option"
    _rec_name="option"
    
    question_id = fields.Many2one('seda.assessment.question')
    option = fields.Char("Option")
    score = fields.Integer("Score")
    
class Question(models.Model):
    _name = "seda.assessment.question"
    _rec_name="question"
    
    question = fields.Text('Question')
    question_Num = fields.Integer("#")
    assessment_id = fields.Many2one('seda.assessment')
    options = fields.Many2many('seda.assessment.question.option',domain="[('question_id','=',id)]",string="Options")
    smme_id = fields.Many2one('sme.assessment')

class Assessment(models.Model):
    _name = "seda.assessment"
    _rec_name="assessment_name"
    
    assessment_name = fields.Char('Title')
    #associated_smme = fields.Many2one('res.users',string="Assessment Custodian")
    
    assessment_questions = fields.One2many('seda.assessment.question','assessment_id',string="Assessment Questions")
    
class SMEAssessment(models.Model):
    _name = "sme.assessment"
    _rec_name="smme_name"
    
    smme_name = fields.Char('SMME Name')
    smme_description = fields.Text("Description of Business")
    user_id = fields.Many2one('res.users',string="Assessment Custodian")
    template_id = fields.Many2one("seda.assessment",string="ERAT Template")
    
    assessment_questions = fields.One2many('seda.assessment.question','smme_id',string="Assessment Questions")
    
    @api.onchange('template_id')
    def _onchange_template_id(self):
        for rec in self:
            rec['assessment_questions'] = rec['template_id']['assessment_questions']
    
    
    
    
    