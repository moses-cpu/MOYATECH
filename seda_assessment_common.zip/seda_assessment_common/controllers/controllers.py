# -*- coding: utf-8 -*-
# from odoo import http


# class SedaAssessmentCommon(http.Controller):
#     @http.route('/seda_assessment_common/seda_assessment_common', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/seda_assessment_common/seda_assessment_common/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('seda_assessment_common.listing', {
#             'root': '/seda_assessment_common/seda_assessment_common',
#             'objects': http.request.env['seda_assessment_common.seda_assessment_common'].search([]),
#         })

#     @http.route('/seda_assessment_common/seda_assessment_common/objects/<model("seda_assessment_common.seda_assessment_common"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('seda_assessment_common.object', {
#             'object': obj
#         })
